ffnn_mnist.py requires the MNIST dataset to be put in the same folder for execution (python-mnist module)

In our code, we use the non-normalized samples and normalize/denormalize them during execution

weights_nao.npy is ued to store the weights after training.
